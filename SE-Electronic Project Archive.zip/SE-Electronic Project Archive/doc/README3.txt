# Integration Tests Documentation - CamboBrew Cafe Management System

## Overview

This document explains how to run the integration tests for the CamboBrew Cafe Management System. Integration tests verify that different components of the application work correctly together, testing the interaction between controllers, models, and middleware.

## Prerequisites

- PHP 8.2 or higher
- Composer installed
- Laravel 11 project set up and dependencies installed
- MySQL or equivalent database for testing (configured in `.env.testing`)

## Setup

1. Clone the repository to your local machine
2. Navigate to the project directory
3. Install dependencies:
   ```
   composer install
   ```
4. Create a testing database:
   ```
   mysql -u root -p -e "CREATE DATABASE coffee_db_testing;"
   ```
5. Configure the testing environment in `.env.testing`:
   ```
   APP_ENV=testing
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=coffee_db_testing
   DB_USERNAME=root
   DB_PASSWORD=123456789
   
   CACHE_DRIVER=array
   SESSION_DRIVER=array
   QUEUE_DRIVER=sync
   MAIL_DRIVER=array
   ```
6. Run migrations for the testing database:
   ```
   php artisan migrate --env=testing
   ```

## Running Integration Tests

For this Laravel 11 application, the feature and integration tests must be run using the following commands from the project root directory:

### Feature Tests

```bash
# API Tests
php artisan test tests/Feature/ApiTests.php

# Chatbot Tests
php artisan test tests/Feature/ChatbotTests.php

# Controller Tests
php artisan test tests/Feature/ControllerTests.php

# Language Tests
php artisan test tests/Feature/LanguageTests.php

# Order Tests
php artisan test tests/Feature/OrderTests.php

# POS Tests
php artisan test tests/Feature/POSTests.php

# Product Tests
php artisan test tests/Feature/ProductTests.php

# Sales Tests
php artisan test tests/Feature/SalesTests.php
```

### Integration Tests

```bash
# Integration Tests
php artisan test tests/Integration/IntegrationTests.php
```

## Available Integration and Feature Tests

### Feature Tests

The system includes the following feature test files:

1. **ApiTests.php**
   - Tests API endpoints and authentication
   - Tests JSON responses and data parsing

2. **ChatbotTests.php**
   - Tests the chatbot routes and responses
   - Verifies the chatbot recommendation system is accessible

3. **ControllerTests.php**
   - Tests basic controller functionality and HTTP responses
   - Tests page loading and authorization

4. **LanguageTests.php**
   - Tests language switching functionality
   - Verifies language routes exist

5. **OrderTests.php**
   - Tests order creation, viewing and updating
   - Tests order status updates
   - Ensures proper relationships between orders and products

6. **POSTests.php**
   - Tests point-of-sale functionality
   - Tests register management and sales processes
   - Tests checkout process with database transactions

7. **ProductTests.php**
   - Tests product creation, editing, and deletion
   - Tests validation and database storage of product details

8. **SalesTests.php**
   - Tests sales reporting features
   - Tests dashboard data calculation and visualization

### Integration Tests

1. **IntegrationTests.php**
   - Tests complete user workflows including authentication flow
   - Tests application navigation between different sections
   - Tests user registration process

## Test Database and Seeding

Integration tests require a test database with appropriate tables and possibly some seed data. The testing environment uses an in-memory SQLite database by default for performance and isolation.

If you need to seed test data, you can create a seeder for testing:

```
php artisan make:seeder TestingDatabaseSeeder
```

Then run the seeder in your test setup:

```
php artisan db:seed --class=TestingDatabaseSeeder --env=testing
```

## Authentication in Tests

Many integration tests require an authenticated user. Use Laravel's testing helpers to simulate authentication:

```php
$user = User::factory()->create(['role' => 'admin']);
$response = $this->actingAs($user)->get('/dashboard');
```

## Troubleshooting

1. **Database Schema Issues**: If tests fail due to missing tables, ensure migrations are running properly in the testing environment:
   ```
   php artisan migrate:fresh --env=testing
   ```

2. **Authentication Failures**: Ensure your tests are properly authenticating users before accessing protected routes.

3. **Route Not Found**: Check that routes are properly defined in your routes files.

4. **Missing Dependencies**: Make sure all required packages are installed with `composer install`.

5. **Memory Limits**: For tests that process a lot of data, you might need to increase PHP memory limit:
   ```
   php -d memory_limit=512M artisan test tests/Feature/SalesTests.php
   ```