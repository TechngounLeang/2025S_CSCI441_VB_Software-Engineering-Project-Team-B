# Unit Tests Documentation - CamboBrew Cafe Management System

## Overview

This document explains how to run the unit tests for the CamboBrew Cafe Management System. Unit tests verify the functionality of individual components (models, controllers, etc.) in isolation.

## Prerequisites

- PHP 8.2 or higher
- Composer installed
- Laravel 11 project set up and dependencies installed
- MySQL or equivalent database for testing (configured in `.env.testing`)

## Setup

1. Clone the repository to your local machine
2. Navigate to the project directory
3. Install dependencies:
   ```
   composer install
   ```
4. Create a testing database:
   ```
   mysql -u root -p -e "CREATE DATABASE coffee_db_testing;"
   ```
5. Configure the testing environment in `.env.testing`:
   ```
   APP_ENV=testing
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=coffee_db_testing
   DB_USERNAME=root
   DB_PASSWORD=123456789
   ```
6. Run migrations for the testing database:
   ```
   php artisan migrate --env=testing
   ```

## Running Unit Tests

For this Laravel 11 application, the unit tests must be run individually using the following commands from the project root directory:

## Running Unit Tests Individually

```bash
# Run Model Tests
php artisan test tests/Unit/ModelTests.php

# Run User Unit Tests
php artisan test tests/Unit/UserUnitTests.php

# Run Category Unit Tests
php artisan test tests/Unit/CategoryUnitTests.php

# Run Order Unit Tests
php artisan test tests/Unit/OrderUnitTests.php

# Run Product Unit Tests
php artisan test tests/Unit/ProductUnitTests.php

# Run Register Unit Tests
php artisan test tests/Unit/RegisterUnitTests.php

# Run Language Unit Tests
php artisan test tests/Unit/LanguageUnitTests.php
```

## Available Unit Tests

The system includes the following unit test files:

1. **ModelTests.php**
   - Tests basic model CRUD operations
   - Includes tests for Product model creation, update, and deletion
   - Tests basic user authentication

2. **UserUnitTests.php**
   - Tests user creation and authentication
   - Tests different user role checks (admin, manager, cashier)
   - Tests password hashing functionality

3. **CategoryUnitTests.php**
   - Tests category creation and relationships
   - Tests validation and database operations for categories

4. **OrderUnitTests.php**
   - Tests Order model methods and relationships
   - Tests order creation with items
   - Tests order status constants and attributes

5. **ProductUnitTests.php**
   - Tests product creation and relationships
   - Tests price formatting and stock management
   - Tests product-category relationships

6. **RegisterUnitTests.php**
   - Tests register model methods
   - Tests register opening and closing processes
   - Tests register user relationships

7. **LanguageUnitTests.php**
   - Tests the LanguageController functionality
   - Verifies the controller returns a proper redirect response

## Test Database Considerations

The unit tests are designed to use an in-memory SQLite database which provides a clean testing environment for each test run. This ensures that tests are isolated and don't affect your development or production data.

For tests that require database interactions, the system uses Laravel's `DatabaseTransactions` trait which wraps each test in a transaction and rolls it back after the test completes, ensuring that the database remains clean between tests.

## Troubleshooting

1. **Database Issues**: If you encounter database-related errors, ensure your `.env.testing` file has the correct database settings.

2. **Test Not Found**: Ensure your test files are in the correct location and have the correct namespace.

3. **Dependencies**: If you encounter class not found errors, try running `composer dump-autoload` to refresh the autoload files.

4. **Memory Limits**: For large test suites, you might need to increase PHP memory limit: `php -d memory_limit=512M artisan test`