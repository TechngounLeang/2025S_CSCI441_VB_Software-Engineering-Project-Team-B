# CamboBrew Cafe Management System - README.txt

## Project Information
- Project Name: CamboBrew Cafe Management System
- Group Number: Group 7
- Group Members:
  - Ratanakvesal Thong
  - Tech Ngoun Leang
  - Longwei Ngor
  - Panhavuth Sok
  - Samady Sok

## File Structure

### Main Files and Directories
- `README.txt` - This file with installation and usage instructions
- `Installation_Guide.pdf` - Detailed installation guide with screenshots
- `User_Manual.pdf` - Comprehensive user guide for all system features
- `Technical_Documentation.pdf` - System architecture and technical specifications
- `/source` - Source code directory containing all application files
- `/database` - Database scripts and migrations
- `/public` - Public-facing web files
- `/storage` - File storage directory

## How to Run the Software

### Prerequisites
- XAMPP 8.2 or higher (includes PHP 8.2+, Apache, and MySQL)
  * Alternatively, you can install individually:
  * PHP 8.2 or higher
  * MySQL 5.7+ or equivalent database
  * Web server (Apache, Nginx, etc.)
- Composer
- Node.js and NPM (for frontend assets)

### Installation Process

#### Step 1: Set Up XAMPP
1. Download and install XAMPP from [Apache Friends](https://www.apachefriends.org/download.html)
2. Start XAMPP Control Panel
3. Start Apache and MySQL services by clicking their respective "Start" buttons
4. Verify that both services are running (green background in the Control Panel)

#### Step 2: Clone the Repository
```bash
git clone https://github.com/TechngounLeang/2025S_CSCI441_VB_Software-Engineering-Project-Team-B.git
cd cambobrew
```

#### Step 3: Install Dependencies
```bash
composer install
npm install
npm run build
```

#### Step 4: Environment Configuration
```bash
cp .env.example .env
```

Edit the `.env` file and configure your database settings:
```
APP_NAME=CamboBrew
APP_ENV=local
APP_DEBUG=true
APP_URL=http://localhost

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=coffee_db
DB_USERNAME=root
DB_PASSWORD=

CACHE_STORE=database
SESSION_DRIVER=database
QUEUE_CONNECTION=database
FILESYSTEM_DISK=local
MAIL_MAILER=log

OPENAI_API_KEY=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  # For chatbot functionality (optional)
```
Note: If you've set a password for your MySQL in XAMPP, include it in the `DB_PASSWORD` field.

#### Step 4: Generate Application Key
```bash
php artisan key:generate
```

#### Step 3: Database Setup
**Option 1: Using Migration Scripts**
```bash
php artisan migrate
php artisan db:seed
```

**Option 2: Using phpMyAdmin (Recommended for beginners)**
1. Start XAMPP Control Panel and ensure Apache and MySQL services are running
2. Open phpMyAdmin in your browser: http://localhost/phpmyadmin
3. Create a new database named `coffee_db`
4. Click on the newly created database, then click the "Import" tab
5. Click "Choose File" and navigate to the `/database/coffee_db.sql` file in the project directory
6. Click "Go" to import the database structure and sample data

Make sure your database settings in the `.env` file match your phpMyAdmin configuration:
```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=coffee_db
DB_USERNAME=root
DB_PASSWORD=
```
Note: The default password for XAMPP's MySQL is empty. If you've set a password, include it in the configuration.

#### Step 6: Storage Link
```bash
php artisan storage:link
```

#### Step 7: Set Proper Permissions (Linux/macOS only)
```bash
chmod -R 755 storage bootstrap/cache
```

#### Step 8: Start the Development Server
```bash
php artisan serve
```

This will start a development server at http://localhost:8000

### Authentication Details

After setting up the system, you can access it with the following default credentials:

#### Admin User
- Email: tech@gmail.com
- Password: password
- Access: Full system access (all modules and settings)

#### Manager User
- Email: panhavuth@gmail.com
- Password: password
- Access: Management functions (no system settings or user management)

#### Cashier User (Demo)
- Email: cashier@cambobrew.com
- Password: password
- Access: POS and basic functions only

**IMPORTANT**: For security reasons, it is strongly recommended to change these default passwords after your first login.

## System Parameters and Usage

### Web Application Access
- URL: http://localhost:8000 (development) or your configured domain
- Compatible browsers: Chrome 88+, Firefox 85+, Safari 14+, Edge 88+
- Minimum screen resolution: 1280 x 720 pixels

### POS System
- Parameter: Register ID
  - Value: Choose from available registers in the system
  - Required for: Opening a register, processing sales
- Parameter: Opening Cash Amount
  - Value: Numeric value (e.g., 100.00)
  - Required for: Opening a register

### Product Management
- Parameter: Product Name
  - Value: Text (1-100 characters)
  - Required for: Adding/editing products
- Parameter: Product Price
  - Value: Numeric value (e.g., 5.99)
  - Required for: Adding/editing products
- Parameter: Category
  - Value: Select from existing categories or create new
  - Required for: Adding/editing products
- Parameter: Stock Quantity
  - Value: Integer (0 or greater)
  - Required for: Adding/editing products
- Parameter: Reorder Level
  - Value: Integer (0 or greater)
  - Required for: Adding/editing products

### Order Processing
- Parameter: Customer Name
  - Value: Text (optional)
  - Required for: Creating new orders
- Parameter: Payment Method
  - Value: Cash, Credit Card, Bank Transfer, PayPal
  - Required for: Processing orders and sales

### Report Generation
- Parameter: Report Type
  - Value: Daily Sales, Weekly Sales, Monthly Sales, Product Performance
  - Required for: Generating reports
- Parameter: Date Range
  - Value: Start date and end date
  - Required for: Generating reports
- Parameter: Export Format
  - Value: CSV, PDF, Excel
  - Required for: Exporting reports

### System Settings
- Parameter: Language
  - Value: English, Spanish, Khmer
  - Required for: Changing display language
- Parameter: Currency Format
  - Value: $ (USD), ៛ (KHR), € (EUR)
  - Required for: Setting currency display

## Troubleshooting

If you encounter issues during installation or operation, please refer to the following solutions:

### Database Connection Issues
1. Verify that your MySQL server is running
2. Check your database credentials in `.env`
3. Ensure the database exists
4. Try running migrations with the `--force` flag:
```bash
php artisan migrate --force
```

### JavaScript or CSS Not Loading
1. Make sure you've run `npm install` and `npm run build`
2. Check for any JavaScript errors in the browser console
3. Run `php artisan storage:link` if images or uploads aren't displaying

### Clearing Cache
If you encounter issues, try clearing the application cache:
```bash
php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear
```

## Support
For any technical issues or questions, please contact the development team:
- Email: support@cambobrew.com
- GitHub: https://github.com/TechngounLeang/2025S_CSCI441_VB_Software-Engineering-Project-Team-B