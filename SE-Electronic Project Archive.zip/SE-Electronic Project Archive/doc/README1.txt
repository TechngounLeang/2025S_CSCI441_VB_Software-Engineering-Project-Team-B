# CamboBrew Cafe Management System

## Overview

CamboBrew is a comprehensive cafe management system that includes Point of Sale (POS), inventory management, sales reporting, and a customer-facing store with an AI-powered chatbot for product recommendations.

## Prerequisites

- PHP 8.2 or higher
- Composer
- MySQL 5.7+ or equivalent database
- Node.js and NPM (for frontend assets)
- Web server (Apache, Nginx, etc.)

## Installation

### Step 1: Clone the Repository

```bash
git clone <https://github.com/TechngounLeang/2025S_CSCI441_VB_Software-Engineering-Project-Team-B.git>
cd cambobrew
```

### Step 2: Install Dependencies

```bash
composer install
npm install
npm run build
```

### Step 3: Environment Configuration

```bash
cp .env.example .env
```

Edit the `.env` file and configure your database settings:

```
APP_NAME=CamboBrew
APP_ENV=local
APP_DEBUG=true
APP_URL=http://localhost

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=coffee_db
DB_USERNAME=root
DB_PASSWORD=123456789

CACHE_STORE=database
SESSION_DRIVER=database
QUEUE_CONNECTION=database
FILESYSTEM_DISK=local
MAIL_MAILER=log

OPENAI_API_KEY=your-openai-api-key  # For chatbot functionality
```

### Step 4: Generate Application Key

```bash
php artisan key:generate
```

### Step 5: Run Migrations and Seed the Database

```bash
php artisan migrate
php artisan db:seed
```

### Step 6: Storage Link

```bash
php artisan storage:link
```

### Step 7: Start the Development Server

```bash
php artisan serve
```

This will start a development server at http://localhost:8000

## System Access

After setting up the system, you can access it with the following default credentials:

### Admin User
- Email: admin@cambobrew.com
- Password: password

### Manager User
- Email: manager@cambobrew.com
- Password: password

### Cashier User
- Email: cashier@cambobrew.com
- Password: password

## System Structure

### Main Modules

1. **Store Front**: Public-facing bakery website
2. **POS System**: For handling in-store sales and register management
3. **Product Management**: For managing bakery products and inventory
4. **Order Management**: For managing customer orders
5. **Sales Dashboard**: For viewing sales analytics and reports
6. **User Management**: For managing staff accounts with different roles

### Key Features

#### Store Front
- Product showcase
- AI-powered product recommendation chatbot
- Mobile-responsive design

#### Point of Sale (POS)
- Quick checkout process
- Register management (open/close with cash balancing)
- Receipt generation

#### Product Management
- Add, edit, and delete products
- Categorize products
- Track inventory levels

#### Order Management
- Process customer orders
- Track order status
- Order history

#### Sales Dashboard
- Daily, weekly, and monthly sales reports
- Sales by payment method
- Export sales data to CSV

#### User Management
- Role-based access control (Admin, Manager, Cashier)
- User profile management

## API Endpoints

The system includes several API endpoints:

```
POST /api/chatbot/recommendation - Get AI-powered product recommendations
```

## Chatbot Integration

The system includes an AI-powered chatbot that recommends products to customers based on their preferences. The chatbot uses the OpenAI API to generate recommendations and is accessible from the store front.

## Multilingual Support

The system supports multiple languages through Laravel's localization system. Currently supported languages:
- English (en)
- Spanish (es)
- Khmer (km)

## Running in Testing Environment

To run the application in testing environment:

1. Create a testing database:
```bash
mysql -u root -p -e "CREATE DATABASE coffee_db_testing;"
```

2. Configure your testing environment:
```bash
cp .env .env.testing
```

3. Edit `.env.testing` to use the testing database:
```
APP_ENV=testing
DB_DATABASE=coffee_db_testing
```

4. Run migrations for testing environment:
```bash
php artisan migrate --env=testing
```

## File Structure Overview

- `app/` - Core application code
  - `Http/Controllers/` - Application controllers
  - `Models/` - Database models
  - `Http/Middleware/` - Request middleware
- `config/` - Configuration files
- `database/` - Database migrations and seeders
- `resources/` - Views, assets, and language files
  - `views/` - Blade templates
  - `css/` - Stylesheets
  - `js/` - JavaScript files
- `routes/` - Application routes
  - `web.php` - Web routes
  - `api.php` - API routes
- `public/` - Publicly accessible files
- `storage/` - File storage
- `tests/` - Application tests
  - `Feature/` - Feature tests
  - `Unit/` - Unit tests
  - `Integration/` - Integration tests

## Troubleshooting

### Clearing Cache

If you encounter issues, try clearing the application cache:

```bash
php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear
```

### Database Connection Issues

If you experience database connection issues:

1. Verify that your MySQL server is running
2. Check your database credentials in `.env`
3. Ensure the database exists
4. Try running migrations with the `--force` flag:
```bash
php artisan migrate --force
```

### JavaScript or CSS Not Loading

If frontend assets aren't loading properly:

1. Make sure you've run `npm install` and `npm run build`
2. Check for any JavaScript errors in the browser console
3. Run `php artisan storage:link` if images or uploads aren't displaying

### Permission Issues

If you encounter permission issues on Linux/macOS systems:

```bash
chmod -R 755 storage bootstrap/cache
```