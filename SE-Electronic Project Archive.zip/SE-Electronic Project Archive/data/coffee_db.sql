-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 08, 2025 at 06:38 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coffee_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cache`
--

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('admin@mail.com|127.0.0.1', 'i:2;', 1745209615),
('admin@mail.com|127.0.0.1:timer', 'i:1745209615;', 1745209615),
('l_ngor@mail.fhsu|127.0.0.1', 'i:3;', 1744295900),
('l_ngor@mail.fhsu|127.0.0.1:timer', 'i:1744295900;', 1744295900),
('rt@gmail.co|127.0.0.1', 'i:1;', 1744250728),
('rt@gmail.co|127.0.0.1:timer', 'i:1744250728;', 1744250728),
('rt@gmail.com|127.0.0.1', 'i:1;', 1744250801),
('rt@gmail.com|127.0.0.1:timer', 'i:1744250801;', 1744250801),
('tech@mail.com|127.0.0.1', 'i:2;', 1746678816),
('tech@mail.com|127.0.0.1:timer', 'i:1746678816;', 1746678816),
('techngoun@mail.com|127.0.0.1', 'i:2;', 1746678785),
('techngoun@mail.com|127.0.0.1:timer', 'i:1746678785;', 1746678785);

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Drinks', '2025-01-02 03:00:00', '2025-01-02 03:00:00'),
(2, 'Pastries', '2025-01-02 03:00:00', '2025-01-02 03:00:00'),
(3, 'Bread', '2025-01-02 03:00:00', '2025-01-02 03:00:00'),
(4, 'Seasonal', '2025-01-02 03:00:00', '2025-01-02 03:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2025_02_12_165532_create_products_table', 1),
(5, '2025_02_12_183543_create_users_table', 2),
(6, '2025_03_04_164812_create_categories_table', 2),
(7, '2025_04_08_083957_add_category_id_to_products_table', 3),
(8, '2025_03_24_124823_create_registers_table', 1),
(9, '2025_04_08_085223_create_sales_table', 4),
(10, '2025_04_08_085435_create_orders_table', 5),
(11, '2025_04_08_085552_create_order_items_table', 5),
(12, '2025_04_08_090510_add_register_id_to_orders_table', 6),
(13, '2025_04_08_094459_add_price_columns_to_order_items_table', 7);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_email` varchar(255) DEFAULT NULL,
  `status` enum('pending','processing','completed','cancelled') NOT NULL DEFAULT 'pending',
  `total_amount` decimal(10,2) NOT NULL,
  `payment_method` enum('cash','credit_card','bank_transfer','paypal') NOT NULL DEFAULT 'cash',
  `notes` text DEFAULT NULL,
  `order_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `register_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `customer_name`, `customer_email`, `status`, `total_amount`, `payment_method`, `notes`, `order_date`, `created_at`, `updated_at`, `register_id`) VALUES
(1, 2, 'David Brown', 'david@example.com', 'completed', 12.45, 'cash', 'Regular customer', '2025-01-15 02:30:00', '2025-01-15 02:30:00', '2025-01-15 02:35:00', 1),
(2, 1, 'Lisa Garcia', 'lisa@example.com', 'completed', 8.75, '', 'First visit', '2025-01-20 07:15:00', '2025-01-20 07:15:00', '2025-01-20 07:20:00', 3),
(3, 3, 'Robert Taylor', 'robert@example.com', 'completed', 15.25, 'cash', 'Regular - gets coffee every morning', '2025-02-01 01:00:00', '2025-02-01 01:00:00', '2025-02-01 01:05:00', 1),
(4, NULL, 'Jennifer Martinez', 'jennifer@example.com', 'completed', 22.50, '', 'Office order', '2025-02-08 04:30:00', '2025-02-08 04:30:00', '2025-02-08 04:40:00', 3),
(5, 2, 'Alex Wong', 'alex@example.com', 'completed', 9.45, 'cash', 'Requested sugar-free options', '2025-02-17 02:00:00', '2025-02-17 02:00:00', '2025-02-17 02:10:00', 3),
(6, 1, 'Sophia Kim', 'sophia@example.com', 'completed', 16.50, '', 'First visit - found us online', '2025-02-22 06:00:00', '2025-02-22 06:00:00', '2025-02-22 06:05:00', 3),
(7, 3, 'Maria Rodriguez', 'maria@example.com', 'completed', 12.75, 'cash', 'Regular weekday customer', '2025-03-03 03:00:00', '2025-03-03 03:00:00', '2025-03-03 03:10:00', 1),
(8, 2, 'Daniel Miles', 'daniel@example.com', 'completed', 18.25, '', 'Office order - weekly pickup', '2025-03-07 02:30:00', '2025-03-07 02:30:00', '2025-03-07 02:40:00', 3),
(9, NULL, 'Emma Wilson', 'emma@example.com', 'cancelled', 12.75, '', 'Wrong order placed - cancelled', '2025-03-10 07:00:00', '2025-03-10 07:00:00', '2025-03-10 07:30:00', 2),
(10, 1, 'Noah Parker', 'noah@example.com', 'completed', 9.95, 'cash', 'Student - morning coffee run', '2025-03-15 01:00:00', '2025-03-15 01:00:00', '2025-03-15 01:05:00', 1),
(11, 3, 'Olivia Johnson', 'olivia@example.com', 'completed', 14.50, '', 'Birthday celebration', '2025-03-22 08:30:00', '2025-03-22 08:30:00', '2025-03-22 08:40:00', 1),
(12, 2, 'William Lee', 'william@example.com', 'completed', 11.25, 'cash', 'Frequent visitor', '2025-03-28 05:00:00', '2025-03-28 05:00:00', '2025-03-28 05:10:00', 3),
(13, NULL, 'Emily Davis', 'emily@example.com', 'completed', 22.25, 'cash', 'First-time customer', '2025-04-01 03:00:00', '2025-04-01 03:00:00', '2025-04-01 03:15:00', 3),
(14, 1, 'James Wilson', 'james@example.com', 'completed', 18.95, '', 'Office meeting order', '2025-04-03 02:00:00', '2025-04-03 02:00:00', '2025-04-03 02:10:00', 1),
(15, 2, 'Ava Martinez', 'ava@example.com', 'completed', 27.50, '', 'Family breakfast', '2025-04-05 01:30:00', '2025-04-05 01:30:00', '2025-04-05 01:45:00', 2),
(16, 3, 'Ethan Thompson', 'ethan@example.com', 'completed', 16.25, 'cash', 'Regular customer', '2025-04-08 04:00:00', '2025-04-08 04:00:00', '2025-04-08 04:05:00', 1),
(17, NULL, 'Charlotte Brown', 'charlotte@example.com', 'completed', 23.75, '', 'Business meeting', '2025-04-10 07:30:00', '2025-04-10 07:30:00', '2025-04-10 07:40:00', 3),
(18, 1, 'Mason Garcia', 'mason@example.com', 'completed', 19.95, 'cash', 'Weekend brunch', '2025-04-12 03:00:00', '2025-04-12 03:00:00', '2025-04-12 03:15:00', 2),
(19, 2, 'Amelia Rodriguez', 'amelia@example.com', 'completed', 14.50, '', 'After work snack', '2025-04-15 10:00:00', '2025-04-15 10:00:00', '2025-04-15 10:10:00', 1),
(20, 3, 'Logan Martin', 'logan@example.com', 'completed', 25.25, '', 'Group order', '2025-04-18 05:30:00', '2025-04-18 05:30:00', '2025-04-18 05:45:00', 3),
(21, NULL, 'Harper Lee', 'harper@example.com', 'completed', 11.75, 'cash', 'Quick breakfast', '2025-04-21 01:00:00', '2025-04-21 01:00:00', '2025-04-21 01:05:00', 1),
(22, 1, 'Evelyn Clark', 'evelyn@example.com', 'completed', 17.25, '', 'Study session', '2025-04-24 08:30:00', '2025-04-24 08:30:00', '2025-04-24 08:40:00', 2),
(23, 2, 'Jackson White', 'jackson@example.com', 'completed', 31.50, 'cash', 'Family gathering', '2025-04-27 04:00:00', '2025-04-27 04:00:00', '2025-04-27 04:20:00', 3),
(24, 3, 'Abigail Taylor', 'abigail@example.com', 'completed', 20.75, '', 'Business meeting', '2025-04-30 07:00:00', '2025-04-30 07:00:00', '2025-04-30 07:15:00', 1),
(25, NULL, 'Sophia Kim', 'sophia@example.com', 'completed', 27.50, 'cash', 'Repeat customer', '2025-05-01 02:00:00', '2025-05-01 02:00:00', '2025-05-01 02:15:00', 3),
(26, 2, 'Daniel Miles', 'daniel@example.com', 'completed', 33.25, '', 'Office order - large group', '2025-05-02 03:30:00', '2025-05-02 03:30:00', '2025-05-02 03:45:00', 3),
(27, 1, 'Karen Thomas', 'karen@example.com', 'processing', 24.95, 'cash', 'Special dietary needs - gluten-free', '2025-05-03 04:00:00', '2025-05-03 04:00:00', '2025-05-07 11:29:49', 3),
(28, 2, 'Alex Wong', 'alex@example.com', 'completed', 15.45, 'cash', 'Requested sugar-free options', '2025-05-03 07:00:00', '2025-05-03 07:00:00', '2025-05-03 07:10:00', 3),
(29, 3, 'Lisa Garcia', 'lisa@example.com', 'cancelled', 35.50, '', 'Customer cancelled due to delay', '2025-05-04 06:00:00', '2025-05-04 06:00:00', '2025-05-04 06:30:00', 3),
(30, 1, 'Noah Parker', 'noah@example.com', 'completed', 9.95, 'cash', 'Student - morning coffee run', '2025-05-04 01:30:00', '2025-05-04 01:30:00', '2025-05-04 01:35:00', 1),
(31, NULL, 'Jennifer Martinez', 'jennifer@example.com', 'pending', 32.75, '', 'Asked about catering options', '2025-05-05 08:00:00', '2025-05-05 08:00:00', '2025-05-05 08:10:00', 3),
(32, 3, 'Robert Taylor', 'robert@example.com', 'completed', 27.25, 'cash', 'Regular - gets coffee every morning', '2025-05-06 00:30:00', '2025-05-06 00:30:00', '2025-05-06 00:35:00', 1),
(33, 2, 'Emma Wilson', 'emma@example.com', 'cancelled', 12.75, '', 'Wrong order placed - cancelled', '2025-05-06 09:00:00', '2025-05-06 09:00:00', '2025-05-06 09:30:00', 3),
(34, NULL, 'Emily Davis', 'emily@example.com', 'completed', 22.25, 'cash', 'Returning customer', '2025-05-07 05:00:00', '2025-05-07 05:00:00', '2025-05-07 11:35:14', 3),
(35, 2, 'Maria Rodriguez', 'maria@example.com', 'completed', 22.75, '', 'Regular weekday customer', '2025-05-08 02:30:00', '2025-05-07 18:25:02', '2025-05-07 18:25:02', 3);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `unit_price`, `total_price`, `price`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 2, 2.75, 5.50, 2.75, '2025-01-15 02:30:00', '2025-01-15 02:30:00'),
(2, 1, 5, 1, 2.95, 2.95, 2.95, '2025-01-15 02:30:00', '2025-01-15 02:30:00'),
(3, 1, 10, 1, 6.25, 6.25, 6.25, '2025-01-15 02:30:00', '2025-01-15 02:30:00'),
(4, 2, 2, 1, 2.50, 2.50, 2.50, '2025-01-20 07:15:00', '2025-01-20 07:15:00'),
(5, 2, 6, 2, 3.50, 7.00, 3.50, '2025-01-20 07:15:00', '2025-01-20 07:15:00'),
(6, 3, 3, 1, 3.75, 3.75, 3.75, '2025-02-01 01:00:00', '2025-02-01 01:00:00'),
(7, 3, 12, 1, 4.25, 4.25, 4.25, '2025-02-01 01:00:00', '2025-02-01 01:00:00'),
(8, 3, 5, 3, 2.95, 8.85, 2.95, '2025-02-01 01:00:00', '2025-02-01 01:00:00'),
(9, 4, 8, 2, 5.95, 11.90, 5.95, '2025-02-08 04:30:00', '2025-02-08 04:30:00'),
(10, 4, 11, 1, 6.25, 6.25, 6.25, '2025-02-08 04:30:00', '2025-02-08 04:30:00'),
(11, 4, 4, 1, 4.25, 4.25, 4.25, '2025-02-08 04:30:00', '2025-02-08 04:30:00'),
(12, 5, 2, 1, 2.50, 2.50, 2.50, '2025-02-17 02:00:00', '2025-02-17 02:00:00'),
(13, 5, 6, 2, 3.50, 7.00, 3.50, '2025-02-17 02:00:00', '2025-02-17 02:00:00'),
(14, 6, 4, 2, 4.25, 8.50, 4.25, '2025-02-22 06:00:00', '2025-02-22 06:00:00'),
(15, 6, 5, 3, 2.95, 8.85, 2.95, '2025-02-22 06:00:00', '2025-02-22 06:00:00'),
(16, 7, 1, 1, 2.75, 2.75, 2.75, '2025-03-03 03:00:00', '2025-03-03 03:00:00'),
(17, 7, 7, 2, 4.95, 9.90, 4.95, '2025-03-03 03:00:00', '2025-03-03 03:00:00'),
(18, 8, 10, 2, 6.25, 12.50, 6.25, '2025-03-07 02:30:00', '2025-03-07 02:30:00'),
(19, 8, 13, 1, 4.50, 4.50, 4.50, '2025-03-07 02:30:00', '2025-03-07 02:30:00'),
(20, 9, 3, 1, 3.75, 3.75, 3.75, '2025-03-10 07:00:00', '2025-03-10 07:00:00'),
(21, 9, 5, 2, 2.95, 5.90, 2.95, '2025-03-10 07:00:00', '2025-03-10 07:00:00'),
(22, 9, 9, 1, 4.50, 4.50, 4.50, '2025-03-10 07:00:00', '2025-03-10 07:00:00'),
(23, 10, 1, 2, 2.75, 5.50, 2.75, '2025-03-15 01:00:00', '2025-03-15 01:00:00'),
(24, 10, 11, 1, 6.25, 6.25, 6.25, '2025-03-15 01:00:00', '2025-03-15 01:00:00'),
(25, 11, 3, 2, 3.75, 7.50, 3.75, '2025-03-22 08:30:00', '2025-03-22 08:30:00'),
(26, 11, 6, 2, 3.50, 7.00, 3.50, '2025-03-22 08:30:00', '2025-03-22 08:30:00'),
(27, 12, 1, 1, 2.75, 2.75, 2.75, '2025-03-28 05:00:00', '2025-03-28 05:00:00'),
(28, 12, 5, 3, 2.95, 8.85, 2.95, '2025-03-28 05:00:00', '2025-03-28 05:00:00'),
(29, 13, 1, 2, 2.75, 5.50, 2.75, '2025-04-01 03:00:00', '2025-04-01 03:00:00'),
(30, 13, 5, 3, 2.95, 8.85, 2.95, '2025-04-01 03:00:00', '2025-04-01 03:00:00'),
(31, 13, 7, 1, 4.95, 4.95, 4.95, '2025-04-01 03:00:00', '2025-04-01 03:00:00'),
(32, 14, 3, 2, 3.75, 7.50, 3.75, '2025-04-03 02:00:00', '2025-04-03 02:00:00'),
(33, 14, 6, 2, 3.50, 7.00, 3.50, '2025-04-03 02:00:00', '2025-04-03 02:00:00'),
(34, 14, 10, 1, 6.25, 6.25, 6.25, '2025-04-03 02:00:00', '2025-04-03 02:00:00'),
(35, 15, 8, 3, 5.95, 17.85, 5.95, '2025-04-05 01:30:00', '2025-04-05 01:30:00'),
(36, 15, 9, 2, 4.50, 9.00, 4.50, '2025-04-05 01:30:00', '2025-04-05 01:30:00'),
(37, 16, 1, 2, 2.75, 5.50, 2.75, '2025-04-08 04:00:00', '2025-04-08 04:00:00'),
(38, 16, 11, 1, 6.25, 6.25, 6.25, '2025-04-08 04:00:00', '2025-04-08 04:00:00'),
(39, 16, 12, 1, 4.25, 4.25, 4.25, '2025-04-08 04:00:00', '2025-04-08 04:00:00'),
(40, 17, 4, 2, 4.25, 8.50, 4.25, '2025-04-10 07:30:00', '2025-04-10 07:30:00'),
(41, 17, 7, 2, 4.95, 9.90, 4.95, '2025-04-10 07:30:00', '2025-04-10 07:30:00'),
(42, 17, 13, 1, 4.50, 4.50, 4.50, '2025-04-10 07:30:00', '2025-04-10 07:30:00'),
(43, 25, 4, 2, 4.25, 8.50, 4.25, '2025-05-01 02:00:00', '2025-05-01 02:00:00'),
(44, 25, 8, 3, 5.95, 17.85, 5.95, '2025-05-01 02:00:00', '2025-05-01 02:00:00'),
(45, 25, 9, 1, 4.50, 4.50, 4.50, '2025-05-01 02:00:00', '2025-05-01 02:00:00'),
(46, 26, 10, 3, 6.25, 18.75, 6.25, '2025-05-02 03:30:00', '2025-05-02 03:30:00'),
(47, 26, 11, 1, 6.25, 6.25, 6.25, '2025-05-02 03:30:00', '2025-05-02 03:30:00'),
(48, 26, 13, 2, 4.50, 9.00, 4.50, '2025-05-02 03:30:00', '2025-05-02 03:30:00'),
(49, 27, 2, 2, 2.50, 5.00, 2.50, '2025-05-03 04:00:00', '2025-05-03 04:00:00'),
(50, 27, 6, 3, 3.50, 10.50, 3.50, '2025-05-03 04:00:00', '2025-05-03 04:00:00'),
(51, 27, 7, 2, 4.95, 9.90, 4.95, '2025-05-03 04:00:00', '2025-05-03 04:00:00'),
(52, 28, 1, 2, 2.75, 5.50, 2.75, '2025-05-03 07:00:00', '2025-05-03 07:00:00'),
(53, 28, 5, 2, 2.95, 5.90, 2.95, '2025-05-03 07:00:00', '2025-05-03 07:00:00'),
(54, 28, 12, 1, 4.25, 4.25, 4.25, '2025-05-03 07:00:00', '2025-05-03 07:00:00'),
(55, 29, 3, 3, 3.75, 11.25, 3.75, '2025-05-04 06:00:00', '2025-05-04 06:00:00'),
(56, 29, 8, 2, 5.95, 11.90, 5.95, '2025-05-04 06:00:00', '2025-05-04 06:00:00'),
(57, 29, 10, 2, 6.25, 12.50, 6.25, '2025-05-04 06:00:00', '2025-05-04 06:00:00'),
(58, 30, 1, 2, 2.75, 5.50, 2.75, '2025-05-04 01:30:00', '2025-05-04 01:30:00'),
(59, 30, 5, 1, 2.95, 2.95, 2.95, '2025-05-04 01:30:00', '2025-05-04 01:30:00'),
(60, 30, 13, 1, 4.50, 4.50, 4.50, '2025-05-04 01:30:00', '2025-05-04 01:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `stock_quantity` int(11) DEFAULT 0,
  `reorder_level` int(11) DEFAULT 0,
  `photo_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `created_at`, `updated_at`, `category_id`, `stock_quantity`, `reorder_level`, `photo_path`) VALUES
(1, 'Espresso', 'Rich, concentrated coffee served in a small cup with a smooth crema on top', 2.75, '2025-05-07 18:19:51', '2025-05-07 11:38:05', 1, 998, 20, 'img/espresso.jpg'),
(2, 'Iced Tea', 'Refreshing cold tea served with ice and optional lemon slice', 2.50, '2025-05-07 18:19:51', '2025-05-07 18:19:51', 1, 999, 20, 'img/iced-tea.jpg'),
(3, 'Iced Latte', 'Smooth espresso with cold milk poured over ice', 3.75, '2025-05-07 18:19:51', '2025-05-07 18:19:51', 1, 999, 20, 'img/icelatte.jpg'),
(4, 'Iced Matcha Latte', 'Creamy cold matcha green tea with milk over ice', 4.25, '2025-05-07 18:19:51', '2025-05-07 18:19:51', 1, 999, 20, 'img/iced_matcha_Latte.jpg'),
(5, 'Croissant', 'Buttery, flaky pastry with a golden-brown exterior and soft layers inside', 2.95, '2025-05-07 18:19:51', '2025-05-07 18:19:51', 2, 40, 10, 'img/croissant.png'),
(6, 'Chocolate Truffle Cake', 'Rich chocolate cake with truffle filling', 3.50, '2025-05-07 18:19:51', '2025-05-07 18:19:51', 2, 50, 10, 'img/chocolatetruffleake.png'),
(7, 'Cheery Cheesecake', 'Creamy classic cheesecake with cherry topping', 4.95, '2025-05-07 18:19:51', '2025-05-07 18:19:51', 2, 25, 5, 'img/cheerycheescake.png'),
(8, 'Pancake', 'Fluffy, golden pancakes served with maple syrup', 5.95, '2025-05-07 18:19:51', '2025-05-07 18:19:51', 2, 30, 8, 'img/pancake.png'),
(9, 'Tart', 'Sweet pastry shell filled with fresh fruits or custard', 4.50, '2025-05-07 18:19:51', '2025-05-07 18:19:51', 2, 20, 5, 'img/tart.png'),
(10, 'Macarons', 'Delicate French meringue-based confection in assorted flavors', 6.25, '2025-05-07 18:19:51', '2025-05-07 18:19:51', 2, 15, 5, 'img/macarons.png'),
(11, 'Ham Sandwich', 'Fresh bread with sliced ham, cheese, and vegetables', 6.25, '2025-05-07 18:19:51', '2025-05-07 18:19:51', 3, 15, 5, 'img/hamsandwich.png'),
(12, 'Bread', 'Freshly baked artisanal bread with a crispy crust', 4.25, '2025-05-07 18:19:51', '2025-05-07 18:19:51', 3, 25, 8, 'img/bread.png'),
(13, 'Wheat Bread', 'Nutritious whole wheat bread, perfect for sandwiches', 4.50, '2025-05-07 18:19:51', '2025-05-07 18:19:51', 3, 20, 5, 'img/wheatbread.png');

-- --------------------------------------------------------

--
-- Table structure for table `registers`
--

CREATE TABLE `registers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` enum('open','closed') NOT NULL DEFAULT 'closed',
  `cash_balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  `counted_balance` decimal(10,2) DEFAULT NULL,
  `balance_difference` decimal(10,2) DEFAULT NULL,
  `opened_at` timestamp NULL DEFAULT NULL,
  `opened_by` bigint(20) UNSIGNED DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  `closed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `transaction_count` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `registers`
--

INSERT INTO `registers` (`id`, `name`, `status`, `cash_balance`, `counted_balance`, `balance_difference`, `opened_at`, `opened_by`, `closed_at`, `closed_by`, `transaction_count`, `created_at`, `updated_at`) VALUES
(1, 'Main Counter', 'open', 500.00, 500.00, 0.00, '2025-05-07 18:18:56', 1, NULL, NULL, 120, '2025-01-02 02:00:00', '2025-05-07 18:18:56'),
(2, 'Side Counter', 'closed', 0.00, 0.00, 0.00, NULL, NULL, NULL, NULL, 65, '2025-01-02 02:00:00', '2025-05-07 18:18:56'),
(3, 'Drive Thru', 'open', 302.97, 300.00, 0.00, '2025-05-07 18:18:56', 2, NULL, NULL, 96, '2025-01-02 02:00:00', '2025-05-07 11:38:05');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `register_id` bigint(20) UNSIGNED DEFAULT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `tax_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payment_method` varchar(255) NOT NULL DEFAULT 'cash',
  `sale_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `user_id`, `register_id`, `total_price`, `tax_amount`, `discount_amount`, `payment_method`, `sale_date`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 12.45, 1.05, 0.00, 'cash', '2025-01-15 02:35:00', '2025-01-15 02:35:00', '2025-01-15 02:35:00'),
(2, 1, 3, 8.75, 0.75, 0.00, 'credit', '2025-01-20 07:20:00', '2025-01-20 07:20:00', '2025-01-20 07:20:00'),
(3, 3, 1, 15.25, 1.30, 0.00, 'cash', '2025-02-01 01:05:00', '2025-02-01 01:05:00', '2025-02-01 01:05:00'),
(4, 1, 3, 22.50, 1.90, 0.00, 'credit', '2025-02-08 04:40:00', '2025-02-08 04:40:00', '2025-02-08 04:40:00'),
(5, 2, 3, 9.45, 0.80, 0.00, 'cash', '2025-02-17 02:10:00', '2025-02-17 02:10:00', '2025-02-17 02:10:00'),
(6, 1, 3, 16.50, 1.40, 0.00, 'debit', '2025-02-22 06:05:00', '2025-02-22 06:05:00', '2025-02-22 06:05:00'),
(7, 3, 1, 12.75, 1.08, 0.00, 'cash', '2025-03-03 03:10:00', '2025-03-03 03:10:00', '2025-03-03 03:10:00'),
(8, 2, 3, 18.25, 1.55, 0.00, 'credit', '2025-03-07 02:40:00', '2025-03-07 02:40:00', '2025-03-07 02:40:00'),
(10, 1, 1, 9.95, 0.85, 0.00, 'cash', '2025-03-15 01:05:00', '2025-03-15 01:05:00', '2025-03-15 01:05:00'),
(11, 3, 1, 14.50, 1.23, 0.00, 'credit', '2025-03-22 08:40:00', '2025-03-22 08:40:00', '2025-03-22 08:40:00'),
(12, 2, 3, 11.25, 0.96, 0.00, 'cash', '2025-03-28 05:10:00', '2025-03-28 05:10:00', '2025-03-28 05:10:00'),
(13, 1, 3, 22.25, 1.89, 0.00, 'cash', '2025-04-01 03:15:00', '2025-04-01 03:15:00', '2025-04-01 03:15:00'),
(14, 1, 1, 18.95, 1.61, 0.00, 'credit', '2025-04-03 02:10:00', '2025-04-03 02:10:00', '2025-04-03 02:10:00'),
(15, 2, 2, 27.50, 2.34, 0.00, 'debit', '2025-04-05 01:45:00', '2025-04-05 01:45:00', '2025-04-05 01:45:00'),
(16, 3, 1, 16.25, 1.38, 0.00, 'cash', '2025-04-08 04:05:00', '2025-04-08 04:05:00', '2025-04-08 04:05:00'),
(17, 1, 3, 23.75, 2.02, 0.00, 'credit', '2025-04-10 07:40:00', '2025-04-10 07:40:00', '2025-04-10 07:40:00'),
(18, 1, 2, 19.95, 1.70, 0.00, 'cash', '2025-04-12 03:15:00', '2025-04-12 03:15:00', '2025-04-12 03:15:00'),
(19, 2, 1, 14.50, 1.23, 0.00, 'credit', '2025-04-15 10:10:00', '2025-04-15 10:10:00', '2025-04-15 10:10:00'),
(20, 3, 3, 25.25, 2.15, 0.00, 'debit', '2025-04-18 05:45:00', '2025-04-18 05:45:00', '2025-04-18 05:45:00'),
(21, 1, 1, 11.75, 1.00, 0.00, 'cash', '2025-04-21 01:05:00', '2025-04-21 01:05:00', '2025-04-21 01:05:00'),
(22, 1, 2, 17.25, 1.47, 0.00, 'credit', '2025-04-24 08:40:00', '2025-04-24 08:40:00', '2025-04-24 08:40:00'),
(23, 2, 3, 31.50, 2.68, 0.00, 'cash', '2025-04-27 04:20:00', '2025-04-27 04:20:00', '2025-04-27 04:20:00'),
(24, 3, 1, 20.75, 1.76, 0.00, 'debit', '2025-04-30 07:15:00', '2025-04-30 07:15:00', '2025-04-30 07:15:00'),
(25, 3, 3, 27.50, 2.34, 0.00, 'cash', '2025-05-01 02:15:00', '2025-05-01 02:15:00', '2025-05-01 02:15:00'),
(26, 2, 3, 33.25, 2.82, 2.50, 'credit', '2025-05-02 03:45:00', '2025-05-02 03:45:00', '2025-05-02 03:45:00'),
(27, 2, 3, 15.45, 1.31, 0.00, 'cash', '2025-05-03 07:10:00', '2025-05-03 07:10:00', '2025-05-03 07:10:00'),
(28, 1, 1, 9.95, 0.85, 0.00, 'cash', '2025-05-04 01:35:00', '2025-05-04 01:35:00', '2025-05-04 01:35:00'),
(29, 3, 1, 27.25, 2.32, 0.00, 'cash', '2025-05-06 00:35:00', '2025-05-06 00:35:00', '2025-05-06 00:35:00'),
(30, 3, 3, 22.25, 1.89, 0.00, 'cash', '2025-05-07 11:35:14', '2025-05-07 11:35:14', '2025-05-07 11:35:14'),
(31, 2, 3, 22.75, 1.93, 0.00, 'debit', '2025-05-07 18:25:02', '2025-05-07 18:25:02', '2025-05-07 18:25:02');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('duKO5ps8yEGxOphZuYP7veMZXCgAoKVzpi8q71kN', 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiaGV5WFc4WlNBdHk5Tmhpc0haRElkQ2ttaVQ1R0o2REtpcUNrdDVVdiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9kYXNoYm9hcmQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToyO30=', 1746679077);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` enum('admin','manager','cashier') NOT NULL DEFAULT 'cashier'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `role`) VALUES
(1, 'RT', 'rt@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', NULL, '2025-04-08 01:37:26', '2025-04-08 01:37:26', 'admin'),
(2, 'Tech', 'tech@gmail.com', '$2y$12$XxdtZ2/QpA0nlo0czLjMW.NwKo6OypOkePJoxy.v9TBwVls8/tAcW', NULL, '2025-04-10 12:03:23', '2025-05-07 21:37:19', 'admin'),
(3, 'Samady', 'samady@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', NULL, '2025-04-10 09:39:25', '2025-04-10 09:39:25', 'admin'),
(4, 'Longwei', 'longwei@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', NULL, '2025-04-10 12:42:22', '2025-04-10 12:42:22', 'admin'),
(5, 'Panhavuth', 'panhavuth@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', NULL, '2025-04-10 12:42:22', '2025-04-10 12:42:22', 'manager');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_name_unique` (`name`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`),
  ADD KEY `orders_register_id_foreign` (`register_id`),
  ADD KEY `idx_orders_status` (`status`),
  ADD KEY `idx_orders_customer_name` (`customer_name`),
  ADD KEY `idx_orders_created_at` (`created_at`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_items_order_id_foreign` (`order_id`),
  ADD KEY `order_items_product_id_foreign` (`product_id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_category_id_foreign` (`category_id`);

--
-- Indexes for table `registers`
--
ALTER TABLE `registers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `registers_opened_by_foreign` (`opened_by`),
  ADD KEY `registers_closed_by_foreign` (`closed_by`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sales_user_id_foreign` (`user_id`),
  ADD KEY `sales_register_id_foreign` (`register_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `registers`
--
ALTER TABLE `registers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_register_id_foreign` FOREIGN KEY (`register_id`) REFERENCES `registers` (`id`),
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `fk_order_items_order_id` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_order_items_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `registers`
--
ALTER TABLE `registers`
  ADD CONSTRAINT `registers_closed_by_foreign` FOREIGN KEY (`closed_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `registers_opened_by_foreign` FOREIGN KEY (`opened_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_register_id_foreign` FOREIGN KEY (`register_id`) REFERENCES `registers` (`id`),
  ADD CONSTRAINT `sales_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
